//https://www.geeksforgeeks.org/problems/merge-two-binary-max-heap0144/1

class Solution{
    public:
    void heapify(vector<int>&output,int i,int n){
        
        int largest=i;
        int left = 2*i+1;
        int right = 2*i+2;
        
        if(left<n && output[largest]<output[left]){
            largest=left;
        }
        
        if(right<n && output[largest]<output[right]){
            largest=right;
        }
        
        if(largest!=i){
            swap(output[largest],output[i]);
            heapify(output,largest,n);
        }
    }
    vector<int> mergeHeaps(vector<int> &a, vector<int> &b, int n, int m) {
        
        vector<int>output;
        
        for(int i=0;i<n;i++){
            output.push_back(a[i]);
        }
        
        for(int i=0;i<m;i++){
            output.push_back(b[i]);
        }
        
        // Start heapification from the last non-leaf node to the root
        //Leaf nodes, by definition, don't have any children. Hence, they trivially satisfy the heap property. There's nothing to "heapify" for them.
        for (int i = (n + m) / 2 - 1; i >= 0; i--) {
            heapify(output, i, n + m);
        }
        return output;
    }
};
