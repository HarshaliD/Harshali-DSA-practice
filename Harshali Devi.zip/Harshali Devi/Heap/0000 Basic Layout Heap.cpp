#include <iostream>
using namespace std;

class heap{
    
    public:
        int array[100];
        int size;
        
        heap(){
            array[0]=-1;
            size=0;
        }
        
        void insert(int val){
            
            size = size+1;
            int index = size;
            array[index] = val;
            
            while(index > 1){
                int parent = index/2;
                
                if(array[index]>array[parent]){
                    swap(array[index],array[parent]);
                    index = parent;
                }
                else{
                    return;
                }
            }
        }
        
        void deletion(){
            
            if(size==0){
                cout<<"Nothing to delete"<<endl;
                return;
            }
            
            //put last node to root node
            array[1]=array[size];
            //remove last node
            size--;
            
            //put node at correct position
            int i=1;
            while(i<size){
                int leftIndex = 2*i;
                int rightIndex = 2*i+1;
                
                if (leftIndex < size && array[i] < array[leftIndex] && array[leftIndex] > array[rightIndex])
            {
                    swap(array[i], array[leftIndex]);
                    i = leftIndex;
            }

            else if (rightIndex < size && array[i] < array[rightIndex] && array[leftIndex] < array[rightIndex])
            {
                swap(array[i], array[rightIndex]);
                i = rightIndex;
            }
            else{
                return;
            }
            }
        }
        
        void heapify(int arr[],int n,int i){
            
            int largest=i;
            int leftIndex = 2*i;
            int rightIndex = 2*i+1;
            
            if(leftIndex<=n && arr[leftIndex]>arr[largest]){
                largest=leftIndex;
            }
            if(rightIndex<=n && arr[rightIndex]>arr[largest]){
                largest=rightIndex;
            }
            
            if(largest!=i){
                swap(arr[largest],arr[i]);
                heapify(arr,n,largest);
            }
            
        }
        
        void print(){
            for(int i=1;i<=size;i++){
                cout<<array[i]<<" ";
            }
            cout<<endl;
        }
};
int main() {
    
    heap h;
    h.insert(50);
    h.insert(22);
    h.insert(70);
    h.insert(10);
    h.insert(90);
    h.insert(33);
    h.deletion();
    h.deletion();
    h.print();
    
    int arr[6] = {-1,55,56,23,58,45};
    
    int n = 5;
    for(int i=n/2;i>=1;i--){
        h.heapify(arr,n,i);
    }
    
    for(int i=1;i<=n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}
