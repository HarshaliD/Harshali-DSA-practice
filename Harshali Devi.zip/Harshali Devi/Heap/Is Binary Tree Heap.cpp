//https://www.geeksforgeeks.org/problems/is-binary-tree-heap/1


// User Function template for C++

// Structure of node
/*struct Node {
    int data;
    Node *left;
    Node *right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};*/

class Solution {
  public:
  
    int counts(struct Node* root){
        
        //base case
        if(root==NULL){
            return 0;
        }
        
        int ans = 1 + counts(root->left) + counts(root->right);
        return ans;
    }
    
    bool isCBT(struct Node* root ,int index,int totalCounts){
        
        if(root==NULL) return true;
        
        if(index>=totalCounts) return false;
        else{
            bool left = isCBT(root->left,2*index+1,totalCounts);
            bool right = isCBT(root->right,2*index+2,totalCounts);
            return (left && right);
        }
    }
    
    bool isMaxHeap(struct Node* root){
        
        //leaf node
        if(root->left== NULL && root->right==NULL)  return true;
        
        if(root->right==NULL){
            return (root->data > root->left->data);
        }
        else{
            bool left=isMaxHeap(root->left);
            bool right=isMaxHeap(root->right);
            
            if(left && right && (root->data > root->left->data && root->data > root->right->data)){
                return true;
            }
            else{
                return false;
            }
        }
    }
    
    bool isHeap(struct Node* root) {
        
        int index=0;
        int totalCounts = counts(root);
        if(isCBT(root,index,totalCounts) && isMaxHeap(root)){
            return true;
        }
        else{
            return false;
        }
    }
};
