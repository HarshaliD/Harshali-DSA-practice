//https://leetcode.com/problems/sort-characters-by-frequency/

class Solution {
public:
    string frequencySort(string s) {
        
        priority_queue<pair<int,char>>maxheap;

        unordered_map<char,int>hashmap;

        for(auto i : s){
            hashmap[i]++;
        }

        for(auto i : hashmap){
            maxheap.push({i.second,i.first});
        }

        string output;

        while(!maxheap.empty()) {
            output += string(maxheap.top().first, maxheap.top().second);
            maxheap.pop();
        }

        return output;
    }
};
