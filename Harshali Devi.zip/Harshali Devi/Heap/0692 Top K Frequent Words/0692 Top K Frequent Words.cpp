//https://leetcode.com/problems/top-k-frequent-words/

class Solution {
public:
    vector<string> topKFrequent(vector<string>& words, int k) {
        
        unordered_map<string, int> hashmap;

        // Count frequencies of each word
        for (auto word : words) {
            hashmap[word]++;
        }

        // Custom comparator for the priority queue
        auto comp = [](const pair<int, string>& a, const pair<int, string>& b) {
            if (a.first == b.first)
                return a.second < b.second; // For min-heap, use '<' for lexicographical order
            return a.first > b.first; // For max-heap, use '>' for frequency order
        };

        // Create a min-heap using the custom comparator
        priority_queue<pair<int, string>, vector<pair<int, string>>, decltype(comp)> minheap(comp);

        // Add elements to the min-heap
        for (auto entry : hashmap) {
            minheap.push({entry.second, entry.first});
            if (minheap.size() > k) {
                minheap.pop();
            }
        }

        // Collect results from the min-heap
        vector<string> output;
        while (!minheap.empty()) {
            output.push_back(minheap.top().second);
            minheap.pop();
        }

        // Reverse the result to get the correct order
        reverse(output.begin(), output.end());

        return output;
    }
};
