//https://leetcode.com/problems/maximum-product-of-two-elements-in-an-array/

class Solution {
public:
    int maxProduct(vector<int>& nums) {
        
        priority_queue<int>maxHeap;

        for(int i=0;i<nums.size();i++){
            maxHeap.push(nums[i]);
        }

        int sum1 = maxHeap.top()-1;
        maxHeap.pop();
        int sum2 = maxHeap.top()-1;
        maxHeap.pop();

        return sum1*sum2;

    }
};

//TC -> O(nlogn)

//Method 2 -> Sorting -> TC -> O (nlogn)
