//https://leetcode.com/problems/min-cost-climbing-stairs/description/

//DP -> Top Down

class Solution {
public:
    int recursion(vector<int>& cost,int index ,vector<int>& memo){
        if(index==cost.size()-1 ||index==cost.size()-2 ){
            return cost[index];
        }
        if(memo[index]!=-1){
            return memo[index];
        }
        int x = recursion(cost,index+1,memo);
        int y = recursion(cost,index+2,memo);

        memo[index] = min(x,y)+cost[index];
        return memo[index];

    }
    int minCostClimbingStairs(vector<int>& cost) {
        if(cost.size()==2){
            return min(cost[0],cost[1]);
        }
        int n = cost.size();
        vector<int>memo(n+1,-1);
        int minCost=-1;
        int x = recursion(cost,0,memo);
        int y = recursion(cost,1,memo);

        return min(x,y);
        
    }
};


//DP -> Bottom Up

class Solution {
public:
    
    int minCostClimbingStairs(vector<int>&cost) {
        int n = cost.size();
        int first = cost[0];
        int second = cost[1];
        if (n<=2) return min(first, second);
        for (int i=2; i<n; i++) {
            int curr = cost[i] + min(first, second);
            first = second;
            second = curr;
        }
        return min(first, second);
    }
};
