//https://leetcode.com/problems/partition-equal-subset-sum

class Solution {
public:
    bool recursion(int sum, int target, int index, vector<int>& nums, vector<vector<int>>& dp, int n) {
        if (sum > target) return false; // Base case when sum exceeds target
        if (sum == target) return true; // Base case when sum equals target
        if (index >= n) return false;   // Base case when index exceeds bounds

        if (dp[index][sum] != -1) return dp[index][sum];

        // Try including the current element
        bool take = recursion(sum + nums[index], target, index + 1, nums, dp, n);

        // Try excluding the current element
        bool nottake = recursion(sum, target, index + 1, nums, dp, n);

        // Store the result in dp array
        return dp[index][sum] = take || nottake;
    }

    bool canPartition(vector<int>& nums) {
        int sum = accumulate(nums.begin(), nums.end(), 0);

        // If the total sum is odd, we can't partition it into two equal subsets
        if (sum % 2 != 0) return false;

        int target = sum / 2;
        int n = nums.size();
        
        // DP table initialized with -1 (indicating uncomputed states)
        vector<vector<int>> dp(n, vector<int>(target + 1, -1));

        // Start recursion from index 0 with sum 0
        return recursion(0, target, 0, nums, dp, n);
    }
};
