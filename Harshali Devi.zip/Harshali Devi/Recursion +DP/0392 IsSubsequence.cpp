//https://leetcode.com/problems/is-subsequence/description/

//Recursion
class Solution {
public:
    bool subsequence(string s, string t,int n,int m){

        if (n == 0) return true;  // All characters in s are matched
        if (m==0) return false; // t is exhausted and s is not matched completely

        // If last characters match, move both pointers
        if (s[n - 1] == t[m - 1]) {
            return subsequence(s, t, n - 1, m - 1);
        } else {
            // If they don't match, move pointer for t only
            return subsequence(s, t, n, m - 1);
        }
    }

    bool isSubsequence(string s, string t) {
       int n=s.size();
       int m=t.size();

       if(n>m){
            return false;
       } 

       return subsequence(s, t, n, m);
    }
};


//Iterative

class Solution {
public:
    bool isSubsequence(string s, string t) {
        int n = s.size();
        int m = t.size();

        // If 's' is longer than 't', it cannot be a subsequence
        if (n > m) return false;

        int i = 0, j = 0; // Two pointers to traverse 's' and 't'

        // Traverse through both strings
        while (i < n && j < m) {
            if (s[i] == t[j]) {
                i++;  // Move pointer for 's' if characters match
            }
            j++;  // Always move pointer for 't'
        }

        // 's' is a subsequence of 't' if all characters in 's' were matched
        return i == n;
    }
};
