//https://leetcode.com/problems/fibonacci-number/description/

//Normal Recursion
class Solution {
public:
    int fib(int n) {
        
        if(n<=1){
            return n;
        }

        return fib(n-1)+fib(n-2);
    }
};

//DP -> TOP DOWN

class Solution {
public:
    int recursion(int n ,vector<int>&dp){
       if(n<=1){
            return n;
        } 

        if(dp[n]!=-1){
            return dp[n];
        }

        dp[n]=recursion(n-1,dp)+recursion(n-2,dp);
        return dp[n];
    }

    int fib(int n) {
        vector<int>dp(n+1,-1);

        int val = recursion(n,dp);
        return val;
    }
};

//DP -> BOTTOM UP

class Solution {
public:
    int fib(int n) {
        
        if(n<=1){
            return n;
        }

        int prev1=1;
        int prev2=0;

        for(int i=2;i<=n;i++){
            int curr = prev1+prev2;
            prev2=prev1;
            prev1=curr;
        }

        return prev1;
    }
};
