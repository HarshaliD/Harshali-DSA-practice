//https://www.geeksforgeeks.org/problems/subset-sum-problem-1611555638/1


//Recursion only -> Time limit exceeded

class Solution{   
public:
    bool recursion(int n,int index,int target,vector<int>arr){
        if(index>=n)return false;
        if(target==0)return true;
        if (target < 0) return false;
        
        bool include = recursion(n, index + 1, target - arr[index], arr);

        bool exclude = recursion(n, index + 1, target, arr);

        return include || exclude;
    }
    bool isSubsetSum(vector<int>arr, int sum){
        
        int n = arr.size();

        return recursion(n, 0, sum, arr);
        
    }
};


//DP -> Memoization

class Solution{   
public:
    bool recursion(vector<int>arr,int sum,vector<vector<int>>&dp,int n,int index){
        
        if(sum==0)return true;
        
        if(index==0)return arr[0]==sum;
        
        if(dp[index][sum]!=-1)return dp[index][sum];
        
        bool nottake = recursion(arr,sum,dp,n,index-1);
        
        bool take=false;
        if(sum>=arr[index]){
            take=recursion(arr,sum-arr[index],dp,n,index-1);
        }
        
        return dp[index][sum]=take||nottake;
    }
    bool isSubsetSum(vector<int>arr, int sum){
        
        int n=arr.size();
        
        vector<vector<int>>dp(n, vector<int>(sum + 1, -1));
        
        bool output = recursion(arr,sum,dp,n,n-1);
        
        return output;
        
        
    }
};

