def left_rotate(arr, k):
    n = len(arr)
    k = k % n  # Ensure k is within bounds
    temp = [0] * n  # Create a temporary array

    # Fill the temporary array with left-rotated values
    for i in range(n):
        temp[i] = arr[(i + k) % n]

    # Copy back to the original array
    for i in range(n):
        arr[i] = temp[i]

# Example usage
arr = [1, 2, 3, 4, 5]
k = 2
left_rotate(arr, k)
print("Left Rotated Array:", arr)  # Output: [3, 4, 5, 1, 2]


def right_rotate(arr, k):
    n = len(arr)
    k = k % n  # Ensure k is within bounds
    temp = [0] * n  # Create a temporary array

    # Fill the temporary array with right-rotated values
    for i in range(n):
        temp[i] = arr[(i - k) % n]

    # Copy back to the original array
    for i in range(n):
        arr[i] = temp[i]

# Example usage
arr = [1, 2, 3, 4, 5]
k = 2
right_rotate(arr, k)
print("Right Rotated Array:", arr)  # Output: [4, 5, 1, 2, 3]
