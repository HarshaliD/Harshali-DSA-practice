//https://leetcode.com/problems/maximum-sum-of-an-hourglass/description/

class Solution {
public:
    int maxSum(vector<vector<int>>& grid) {
        
        int row = grid.size();
        if(row<3) return 0;
        int maxsum = INT_MIN;

        for(int i=0;i<row-2;i++){

            int col=grid[i].size();
            if(col<3)return 0;
            for(int j=0;j<col-2;j++){
                int sum=(grid[i][j]+grid[i][j+1]+grid[i][j+2]+grid[i+1][j+1]+grid[i+2][j]+grid[i+2][j+1]+grid[i+2][j+2]);
                maxsum = max(sum,maxsum);
            }
        }

        return maxsum;

    }
};
