#Hashing

hashmap = {}

arr = [1,2,3,3]

for i in range(len(arr)):
  if(arr[i] in hashmap):
    print(arr[i])
  else:
    hashmap[arr[i]]=1
