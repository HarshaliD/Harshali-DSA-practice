#Method 1
#Anagram

def anagram(s1,s2):
  if(len(s1)!=len(s2)):
    return False
  s1 = list(s1)
  s2 = list(s2)
  s1.sort()
  s2.sort()
  if(s1!=s2):
    return False
  else:
    return True

anagram("siddhi","ddhisi")


#Method 2
def anagram(s1,s2):
  if(len(s1)!=len(s2)):
    return False
  if(sorted(s1)!=sorted(s2)):
    return False
  else:
    return True

anagram("ayushi","yushi")


#Method 3
from collections import Counter

def is_anagram(s,t):
  if len(s)!=len(t):
    return False

  return Counter(s)==Counter(t)         #Use Counter to count the freq of charac in both strings

is_anagram("siddhi","ddhisi")
