//https://leetcode.com/problems/closest-prime-numbers-in-range/description/

#include <cmath>

bool isPrime(int n) {
    // Check for numbers less than or equal to 1
    if (n <= 1) return false;
    // Check for 2 and 3
    if (n <= 3) return true;
    // Eliminate multiples of 2 and 3
    if (n % 2 == 0 || n % 3 == 0) return false;
    // Check for other primes by testing divisibility from 5 upwards
    for (int i = 5; i <= sqrt(n); i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}

