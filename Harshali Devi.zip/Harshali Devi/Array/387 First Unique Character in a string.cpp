//https://leetcode.com/problems/first-unique-character-in-a-string/description/

//Using hashtable 

class Solution {
public:
    int firstUniqChar(string s) {
        
        unordered_map<char,pair<int,int>>hashtable;

        for(int i=0;i<s.size();i++){
            hashtable[s[i]].first++;
            hashtable[s[i]].second=i;
            
        }

        for(int i=0;i<s.size();i++){
            if(hashtable[s[i]].first==1){
                return hashtable[s[i]].second;
            }
        }

        return -1;

    }
};


//using array only

class Solution {
public:
    int firstUniqChar(string s) {
        int arr[26]={0};
        for(int i=0;i<s.size();i++){
            int temp=s[i]-'a';
            arr[temp]++;
        }

        for(int i=0;i<s.size();i++){
            int temp=s[i]-'a';
            if(arr[temp]==1) return i;
        }
        return -1;
    }
};
