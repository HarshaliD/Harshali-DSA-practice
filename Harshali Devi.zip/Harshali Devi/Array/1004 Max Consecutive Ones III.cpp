//Day 19
//https://leetcode.com/problems/max-consecutive-ones-iii/description/

//Approach 1 -> use 2 variables one and zero

class Solution {
public:
    int longestOnes(vector<int>& nums, int k) {
        int zero = 0;
        int one = 0;
        int maxCount = 0;
        int left = 0;
        int right = 0;
        int sum = 0;

        while (right < nums.size()) {
            if (nums[right] == 1) {
                one++;
            } else if (nums[right] == 0) {
                zero++;
            }

            while (zero > k) {
                if (nums[left] == 1) {
                    one--;
                } else if (nums[left] == 0) {
                    zero--;
                }
                left++;
            }

            sum = zero + one;  // Total length of the current valid subarray
            maxCount = max(maxCount, sum);
            right++;
        }

        return maxCount;
    }
};

//Approach 2 -> Use only zero variable

class Solution {
public:
    int longestOnes(vector<int>& nums, int k) {
        int zero = 0;
        int maxCount = 0;
        int left = 0;
        int right = 0;

        while (right < nums.size()) {
            if (nums[right] == 0) {
                zero++;
            }

            while (zero > k) {
                if (nums[left] == 0) {
                    zero--;
                }
                left++;
            }

            maxCount = max(maxCount, right - left + 1);
            right++;
        }

        return maxCount;
    }
};
