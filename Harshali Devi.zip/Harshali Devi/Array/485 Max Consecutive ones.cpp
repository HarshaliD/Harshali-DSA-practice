//https://leetcode.com/problems/max-consecutive-ones/description/

class Solution {
public:
    int findMaxConsecutiveOnes(vector<int>& nums) {
        
        int maxsum=0;
        int count=0;
        for(int i=0;i<nums.size();i++){
            if(nums[i]==0){
                maxsum=max(maxsum,count);
                count=0;
            }
            if(nums[i]==1){
                count++;
            }
        }

        maxsum=max(count,maxsum);

        return maxsum;
    }
};
