//https://leetcode.com/problems/max-consecutive-ones-iii/


class Solution {
public:
    int longestOnes(vector<int>& nums, int k) {

       int num_0 = 0;
       int start = 0;
       int n = nums.size();
       int maxlength=0;

       for(int end=0;end<n;end++){
        if(nums[end]==0){
            num_0++;
        }

        while(num_0>k){
            if(nums[start]==0){
                num_0--;
            }
            start++;
        }

        maxlength = max(maxlength,end-start+1);
       }

       return maxlength;
       
    }
};
