//https://leetcode.com/problems/longest-substring-without-repeating-characters/

class Solution {
public:
    int lengthOfLongestSubstring(string s) {
        
        vector<int>hashmap(128,0);
        int n = s.length();
        int maxLength = 0;

        for(int start=0,end=0;end<n;end++){

            char letter = s[end];
            start = max(start,hashmap[letter]);
            maxLength = max(maxLength,end-start+1);
            hashmap[letter]=end + 1;
        }

        return maxLength;
    }
};

