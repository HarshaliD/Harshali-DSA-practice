//https://leetcode.com/problems/longest-substring-without-repeating-characters/

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:

        n = len(s)
        maxlength = 0
        hashmap = {}
        start=0

        for end in range(n):
            character = s[end]
            start = max(start,hashmap.get(character,0))
            maxlength = max(maxlength,end-start+1)
            hashmap[character]=end+1

        return maxlength
