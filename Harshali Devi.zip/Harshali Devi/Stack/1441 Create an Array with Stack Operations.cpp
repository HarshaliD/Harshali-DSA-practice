//Day 19
//https://leetcode.com/problems/build-an-array-with-stack-operations/description/


class Solution {
public:
    vector<string> buildArray(vector<int>& target, int n) {

        vector<string>output; 
        int index = 0;         //index is needed for target as target starts from 0 index and our numbers start from 1.
        
        for(int i=1;i<=n;i++){
            if(index>=target.size()){
                break;
            }

            output.push_back("Push");
            if(target[index]==i){
                index++;
            }
            else{
                output.push_back("Pop");
            }
        }

        return output;
    }
};
