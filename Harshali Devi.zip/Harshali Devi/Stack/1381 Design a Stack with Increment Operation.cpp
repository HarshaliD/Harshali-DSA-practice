//Day 19
//https://leetcode.com/problems/design-a-stack-with-increment-operation/

//Not so optimized solution -> using stack and vector

class CustomStack {
public:
    stack<int> st;
    int maxSize;
    int count;
    CustomStack(int maxSize) : maxSize(maxSize), count(0) {}
    
    void push(int x) {
        if(count<maxSize){
            st.push(x);
            count++;
        }
    }
    
    int pop() {
        if(st.empty()){
            return -1;
        }
        int top = st.top();
        st.pop();
        count--;
        return top;
    }
    
    void increment(int k, int val) {
        std::vector<int> temp;
        while (!st.empty()) {
            temp.push_back(st.top());
            st.pop();
        }
        std::reverse(temp.begin(), temp.end());
        int limit = std::min(k, count);
        for (int i = 0; i < limit; ++i) {
            temp[i] += val;
        }
        for (int i = 0; i < temp.size(); ++i) {
            st.push(temp[i]);
        }
    }
};


//optimized code -> use stack and optimized pop function

class CustomStack {
public:
    stack<int> st;
    int maxSize;
    vector<int>incremental;
    CustomStack(int maxSize) {
        this->maxSize = maxSize;
        incremental.resize(maxSize, 0);
    }
    
    void push(int x) {
        if(st.size()<maxSize){
            st.push(x);
        }
    }
    
    int pop() {
        if(st.empty()){
            return -1;
        }

        int index=st.size()-1;
        int topVal = st.top()+incremental[index];
        if(index>0){
            incremental[index-1]+=incremental[index];
        }
        st.pop();
        incremental[index]=0;
        return topVal;
    }
    
    void increment(int k, int val) {
        int k1=min(k, (int)st.size());
        if (k1 > 0) {
            incremental[k1 - 1] += val;
        }
    }
};


//Optimized -> Using vectors instead of stack
class CustomStack {
public:
    vector<int>st;
    int maxSize;
    
    CustomStack(int maxSize) {
        this->maxSize=maxSize;
    }
    
    void push(int x) {
        if(st.size()<maxSize){
            st.push_back(x);
        }
    }
    
    int pop() {
        if(st.empty()){
            return -1;
        }
        int res = st.back();
        st.pop_back();
        return res;
    }
    
    void increment(int k, int val) {
        int k1 = min(k,(int)st.size());
        for(int i=0;i<k1;i++){
            st[i]+=val;        
        }
    }
};

/**
 * Your CustomStack object will be instantiated and called as such:
 * CustomStack* obj = new CustomStack(maxSize);
 * obj->push(x);
 * int param_2 = obj->pop();
 * obj->increment(k,val);
 */
