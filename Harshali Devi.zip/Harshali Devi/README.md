Hi there, **I'm Harshali Devi!**

**About Me**:

I'm studying Artificial Intelligence and Data Science at Pune University. I'm very interested in Data Science and Machine Learning, and I love using data to solve real-world problems.

**What I Do**:

->Love Coding: Always excited to learn new technologies and get better at coding.

->Aspiring Data Scientist: Working on projects that involve data analysis, machine learning, and AI.

->Open Source Fan: I like contributing to open source projects and working with the community.

**Let's Connect!**

LeetCode: https://leetcode.com/u/suchd/

LinkedIn: www.linkedin.com/in/harshali-d-b8b141231

*Hoping to learn DSA and practice leetcode daily,using this repository.*
