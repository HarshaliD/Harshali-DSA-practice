//https://leetcode.com/problems/sum-of-left-leaves/description/


//bfs
class Solution {
public:
    int sumOfLeftLeaves(TreeNode* root) {
        
        queue<pair<TreeNode*,char>>q;

        int ans=0;
        q.push({root,'N'});
        while(!q.empty()){
            TreeNode* front = q.front().first;
            char check = q.front().second;
            q.pop();

            if (front->left == nullptr && front->right == nullptr && check == 'L') {
                ans += front->val;
            }

            if(front->left)q.push({front->left,'L'});
            if(front->right)q.push({front->right,'R'});

        }

        return ans;

    }
};


//dfs
class Solution {
public:
    void dfs(TreeNode* root,bool is_left,int& ans){

        if(root==nullptr)return;

        if(root->left==nullptr && root->right==nullptr && is_left){
            ans+=root->val;
        }

        dfs(root->left,true,ans);
        dfs(root->right,false,ans);
    }
    int sumOfLeftLeaves(TreeNode* root) {
        int ans=0;
        dfs(root,false,ans);
        return ans;
    }
};
