//https://leetcode.com/problems/binary-tree-preorder-traversal/description/

// N L R

class Solution {
public:
    void preorder(TreeNode* root,vector<int>&output){
        if(root==nullptr)return;

        output.push_back(root->val);
        preorder(root->left,output);
        preorder(root->right,output);

    }
    vector<int> preorderTraversal(TreeNode* root) {
        
        TreeNode* temp = root;

        vector<int>output;

        preorder(temp,output);

        return output;


    }
