//https://leetcode.com/problems/diameter-of-binary-tree/description/

class Solution {
public:
    int maxdia = 0;
    int height(TreeNode* root){
        if(root==nullptr)return 0;

        int lh=height(root->left);
        int rh=height(root->right);

        maxdia=max(maxdia,lh+rh);

        return 1+max(lh,rh);              //understand
    }
    int diameterOfBinaryTree(TreeNode* root) {
        height(root);
        return maxdia;
    }
};
