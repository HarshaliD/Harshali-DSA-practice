//https://leetcode.com/problems/minimum-absolute-difference-in-bst/


//using vector
class Solution {
public:
    void traversal(TreeNode* root,vector<int>&output){        
        if(root==nullptr)return;

        traversal(root->left,output);
        output.push_back(root->val);
        traversal(root->right,output);
    }
    int getMinimumDifference(TreeNode* root) {
        
        vector<int>output;
        traversal(root,output);

        int diff=INT_MAX;
        for(int i=0;i<output.size()-1;i++){
            diff=min(diff,output[i+1]-output[i]);
        }

        return diff;

    }
};
