//https://leetcode.com/problems/sum-of-root-to-leaf-binary-numbers/


//Method 1 -> less efficient
class Solution {
public:
    int bintodec(string& binary){
        int ans = 0;
        int n = binary.size();
        for(int i=0;i<binary.size();i++){
            ans+=(binary[i]-'0')*pow(2,(n-i-1));
        }
        return ans;
    }
    void recursion(TreeNode* root,int& ans,string binary){

        if(root==nullptr)return;

        binary+=(root->val+'0');

        if(root->left==nullptr && root->right==nullptr){
            ans+=bintodec(binary);
        }

        recursion(root->left,ans,binary);
        recursion(root->right,ans,binary);

        binary.pop_back();
    }
    int sumRootToLeaf(TreeNode* root) {
        
        int ans=0;
        string binary = "";
        recursion(root,ans,binary);

        return ans;

    }
};


//Method 2 

->use << bitwise left shift operator

//Method 3

->use multiply 2 every time while iterating...as 2 raise to anything we multiply

