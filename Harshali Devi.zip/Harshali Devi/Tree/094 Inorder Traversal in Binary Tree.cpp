//https://leetcode.com/problems/binary-tree-inorder-traversal/description/

class Solution {
public:
    void inorder(TreeNode* root,vector<int>&output){

        if(root==nullptr)return;

        inorder(root->left,output);
        output.push_back(root->val);
        inorder(root->right,output);
    }
    vector<int> inorderTraversal(TreeNode* root) {
        
        TreeNode* temp = root;

        vector<int>output;

        inorder(temp,output);

        return output;
    }
};
