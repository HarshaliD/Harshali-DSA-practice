//https://leetcode.com/problems/n-ary-tree-preorder-traversal/description/

class Solution {
public:
    void recursion(Node* root,vector<int>&ans){
        if(root==nullptr)return;

        ans.push_back(root->val);

        for(int i=0;i<root->children.size();i++){
            recursion(root->children[i],ans);
        }
    }
    vector<int> preorder(Node* root) {
        vector<int>ans;
        recursion(root,ans);
        return ans;
    }
};
