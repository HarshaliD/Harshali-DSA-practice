//https://leetcode.com/problems/two-sum-iv-input-is-a-bst/


//Approach 1 -> hashset
class Solution {
public:
    bool findTarget(TreeNode* root, int k) {
        unordered_set<int> seen;
        return find(root, k, seen);
    }

    bool find(TreeNode* node, int k, unordered_set<int>& seen) {
        if (node == nullptr) return false;

        if (seen.count(k - node->val)) {
            return true;
        }

        seen.insert(node->val);

        return find(node->left, k, seen) || find(node->right, k, seen);
    }
};


//Approach 2 -> Inorder traversal+vector

class Solution {
public:
    void inorder(TreeNode* root,vector<int>&output){
        if(root==nullptr)return;

        inorder(root->left,output);
        output.push_back(root->val);
        inorder(root->right,output);

    }
    bool findTarget(TreeNode* root, int k) {

        
        vector<int>output;

        inorder(root,output);

        int start=0;
        int end = output.size()-1;

        while(start<end){
            int sum = output[start]+output[end];
            if(sum==k){
                return true;
            }
            if(sum>k){
                end--;
            }
            else{
                start++;
            }
        }

        return false;

    }
};
