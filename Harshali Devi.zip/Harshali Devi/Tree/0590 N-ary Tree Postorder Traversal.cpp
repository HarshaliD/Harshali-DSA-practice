//https://leetcode.com/problems/n-ary-tree-postorder-traversal/description/

class Solution {
public:

vector<int>ans;
  void solve(Node*root){
      if(root==NULL){
          return;
      }
    for(int i=0;i<root->children.size();i++){
        solve(root->children[i]);
    }

      ans.push_back(root->val);
  }
    vector<int> postorder(Node* root) {
        solve(root);
        return  ans;
    }
};
