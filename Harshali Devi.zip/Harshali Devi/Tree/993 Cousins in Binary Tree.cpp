//https://leetcode.com/problems/cousins-in-binary-tree/

//DFS
class Solution {
public:
    bool isCousins(TreeNode* root, int x, int y) {
        // Variables to store depth and parent of x and y
        int x_depth = -1, y_depth = -1;
        TreeNode* x_parent = nullptr;
        TreeNode* y_parent = nullptr;

        // Helper function for DFS traversal
        dfs(root, x, y, 0, nullptr, x_depth, y_depth, x_parent, y_parent);
        
        // Nodes are cousins if they have the same depth but different parents
        return (x_depth == y_depth) && (x_parent != y_parent);
    }

private:
    void dfs(TreeNode* node, int x, int y, int depth, TreeNode* parent,
             int& x_depth, int& y_depth, TreeNode*& x_parent, TreeNode*& y_parent) {
        if (node == nullptr) return;

        // Check if current node is x or y and update depth and parent accordingly
        if (node->val == x) {
            x_depth = depth;
            x_parent = parent;
        }
        if (node->val == y) {
            y_depth = depth;
            y_parent = parent;
        }

        // Recursively traverse left and right children
        dfs(node->left, x, y, depth + 1, node, x_depth, y_depth, x_parent, y_parent);
        dfs(node->right, x, y, depth + 1, node, x_depth, y_depth, x_parent, y_parent);
    }
};


//BFS
class Solution {
public:
    bool isCousins(TreeNode* root, int x, int y) {
        queue<pair<TreeNode*, TreeNode*>> q;  // pair of (node, parent)

        q.push({root, nullptr});  // Start with the root node, which has no parent

        pair<TreeNode*, TreeNode*> x_info = {nullptr, nullptr};  // (node, parent) for x
        pair<TreeNode*, TreeNode*> y_info = {nullptr, nullptr};  // (node, parent) for y

        while (!q.empty()) {
            int level_size = q.size();
            for (int i = 0; i < level_size; ++i) {
                auto [node, parent] = q.front();
                q.pop();

                // Check if we found x or y
                if (node->val == x) {
                    x_info = {node, parent};
                } else if (node->val == y) {
                    y_info = {node, parent};
                }

                // Push the children into the queue with the current node as their parent
                if (node->left) {
                    q.push({node->left, node});
                }
                if (node->right) {
                    q.push({node->right, node});
                }
            }

            // After processing the level, check if we found both x and y
            if (x_info.first && y_info.first) {
                // Both x and y found at the same level, now check their parents
                return x_info.second != y_info.second;
            }

            // If one is found and not the other, return false as they can't be cousins
            if (x_info.first || y_info.first) {
                return false;
            }
        }

        return false;  // If we exit the loop, x or y wasn't found in the tree
    }
};
