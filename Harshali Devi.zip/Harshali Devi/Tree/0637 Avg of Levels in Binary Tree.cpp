//https://leetcode.com/problems/average-of-levels-in-binary-tree/description/


class Solution {
public:
    vector<double> averageOfLevels(TreeNode* root) {
        
        queue<TreeNode *>q;

        q.push(root);
        q.push(nullptr);   //end of level
        double sum=0;
        int count=0;

        vector<double>ans;

        while(!q.empty()){
            TreeNode* front  = q.front();
            q.pop();

            if(front==nullptr){
                double avg = sum/count;
                sum=0;
                count=0;
                ans.push_back(avg);
                if(q.size()>0)q.push(nullptr);
            }
            else{
                sum+=front->val;
                count++;

                if(front->left)q.push(front->left);

                if(front->right)q.push(front->right);
            }
        }


        return ans;
    }
};
