//https://leetcode.com/problems/path-sum/

class Solution {
public:
    bool traversal(TreeNode* root, int targetSum, int currentSum) {
        if (root == nullptr) return false;

        currentSum += root->val;

        // Check if it's a leaf node and the path sum equals the target sum
        if (root->left == nullptr && root->right == nullptr) {
            return currentSum == targetSum;
        }

        // Recursively check the left and right subtrees
        return traversal(root->left, targetSum, currentSum) || traversal(root->right, targetSum, currentSum);
    }

    bool hasPathSum(TreeNode* root, int targetSum) {
        return traversal(root, targetSum, 0);
    }
};
