//https://leetcode.com/problems/maximum-depth-of-binary-tree/

//method 1
class Solution {
public:
    int maxCount=INT_MIN;
    void recursion(TreeNode* root,int count){

        if(root==nullptr){
            return;
        }

        count++;
        maxCount=max(maxCount,count);

        recursion(root->left,count);
        recursion(root->right,count);

    }
    int maxDepth(TreeNode* root) {
        
        int count=0;

        if(root==nullptr)return count;

        recursion(root,count);

        return maxCount;
 
    }
};

//method 2
 int maxDepth(TreeNode* root) {
        if (root == NULL)
            return 0;
        int l = maxDepth(root->left);
        int r = maxDepth(root->right);
        int t = max(l, r) + 1;                     // +1 for current node
        return t;
 }

