//https://leetcode.com/problems/binary-tree-level-order-traversal/description/

class Solution {
public:
    vector<vector<int>> levelOrder(TreeNode* root) {
        vector<vector<int>>output;
        if(root==nullptr)return output;
        queue<TreeNode*>q;

        q.push(root);

        while(!q.empty()){
            int size = q.size();                            //size is calculated at the beginning of each level's processing. 
                                                            //It represents the number of nodes at the current level.
            vector<int>level;
            for(int i=0;i<size;i++){
                TreeNode* node = q.front();
                q.pop();
                if(node->left!=nullptr){
                    q.push(node->left);
                }
                if(node->right!=nullptr){
                    q.push(node->right);
                }
                level.push_back(node->val);
            }
            output.push_back(level);

        }

        return output;

    }
};
