//https://leetcode.com/problems/symmetric-tree/description/

class Solution {
public:
    bool solve(TreeNode* left,TreeNode* right){
        if(left==nullptr && right==nullptr )return true;

        if(left == nullptr || right == nullptr || left->val != right->val){
            return false;
        }

        return solve(left->left,right->right) && solve(left->right,right->left);


    }
    bool isSymmetric(TreeNode* root) {
        if(root==nullptr)return true;
        bool val = solve(root->left,root->right);
        return val;
    }
};
