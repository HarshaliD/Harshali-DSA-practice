//https://leetcode.com/problems/convert-sorted-array-to-binary-search-tree/description/

//Read TC && SC

class Solution {
public:
    TreeNode* recursion(vector<int>& nums , int start,int end){
        if(start>end)return nullptr;

        int mid = start + (end-start)/2;

        TreeNode* root = new TreeNode(nums[mid]);                    //use 'new' operator for creating new node

        root -> left = recursion(nums,start,mid-1);
        root->right = recursion(nums,mid+1,end);

        return root;

    }
    TreeNode* sortedArrayToBST(vector<int>& nums) {
        
        TreeNode* root = recursion(nums,0,nums.size()-1);

        return root;
    }
};


//TC -> O(n)
//SC -> O(log(n))

/** General rule for log(n):
Whenever you're dealing with a situation where you halve something repeatedly until you reach a small number (usually 1), the number of times you can do this is approximately log₂(n).

How do you know when it’s log(n)?
You’ll see log(n) time or space complexity when:

The problem size is getting cut in half repeatedly. This happens in algorithms like binary search, merge sort, or when building a balanced binary tree (like in your code).
You’re recursively dividing the input, like splitting an array, and the number of divisions grows in powers of 2.
Practice recognizing log(n):
If an algorithm splits things in half (or into parts) at each step, and you're reducing the problem size by dividing it, think log(n).**/


/** Why O(n)?
While the array is being divided in half at each recursive step (which gives us the log(n) recursion depth),
you still need to process every element in the array to build the binary search tree (BST).**/





