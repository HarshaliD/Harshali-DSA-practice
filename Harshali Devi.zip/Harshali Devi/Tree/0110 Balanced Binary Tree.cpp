//https://leetcode.com/problems/balanced-binary-tree/


class Solution {
public:
    int traversal(TreeNode* root){

        if(root==nullptr)return 0;

        int leftHeight = traversal(root->left);

        int rightHeight = traversal(root->right);

        if(leftHeight==-1 || rightHeight==-1)return -1;

        if(abs(leftHeight - rightHeight)>1) return -1;

        return max(leftHeight,rightHeight)+1;
    }
    bool isBalanced(TreeNode* root) {
        
        if(root==nullptr) return true;

        if(traversal(root)==-1) return false;

        return true;
        
    }
};

