//https://leetcode.com/problems/symmetric-tree/description/

class Solution {
public:
    bool check(TreeNode* leftside,TreeNode* rightside){
        if(leftside==nullptr && rightside==nullptr)return true;

        if(leftside==nullptr || rightside==nullptr)return false;

        return (leftside->val == rightside->val) && check(leftside->left,rightside->right) && check(leftside->right,rightside->left);
    }
    bool isSymmetric(TreeNode* root) {
        
        bool output = check(root->left,root->right);

        return output;
    }
};
