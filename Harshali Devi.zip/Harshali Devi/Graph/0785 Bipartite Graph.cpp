//https://leetcode.com/problems/is-graph-bipartite/description/

//DFS SOLUTION
class Solution {
public:
    bool dfs(int node,vector<int>&color,int rang,vector<vector<int>>& graph){

        color[node]=rang;

        for(auto adj : graph[node]){
            if(color[adj]==-1){
                if(dfs(adj,color,1-rang,graph)==false)return false;
            }
            else if(color[adj]==rang)return false;
        }

        return true;
    }
    bool isBipartite(vector<vector<int>>& graph) {
        
        int n=graph.size();
        int m=graph[0].size();

        vector<int>color(n,-1);

        for(int i=0;i<n;i++){
            if(color[i]==-1){
                if(dfs(i,color,0,graph)==false) return false;
            }
        }

        return true;


    }
};


//BFS SOLUTION
class Solution {
public:
    bool isBipartite(vector<vector<int>>& graph) {
        int n = graph.size();
        vector<int> color(n, -1); // Initialize all vertices with no color (-1)
        
        // We need to check all components of the graph
        for (int i = 0; i < n; i++) {
            if (color[i] == -1) { // If this node hasn't been colored
                queue<int> q;
                q.push(i);
                color[i] = 0; // Start coloring with 0
                
                while (!q.empty()) {
                    int node = q.front();
                    q.pop();
                    
                    for (auto adj : graph[node]) {
                        if (color[adj] == -1) {
                            // Color the adjacent node with the opposite color
                            color[adj] = 1 - color[node];
                            q.push(adj);
                        } else if (color[adj] == color[node]) {
                            // If adjacent node has the same color, it's not bipartite
                            return false;
                        }
                    }
                }
            }
        }
        
        return true; // All components are bipartite
    }
};
