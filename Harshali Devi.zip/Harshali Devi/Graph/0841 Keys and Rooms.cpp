//https://leetcode.com/problems/keys-and-rooms/description/

class Solution {
public:
    bool canVisitAllRooms(vector<vector<int>>& rooms) {
        
        vector<int>vis(rooms.size(),0);
        queue<int>q;
        vis[0]=1;
        q.push(0);
        while(!q.empty()){
            int room = q.front();
            q.pop();

            for(auto key : rooms[room]){
                if(vis[key]!=1){
                    q.push(key);
                    vis[key]=1;
                }
            }
        }

        for(auto check : vis){
            if (check==0){
                return false;
            }
        }

        return true;

    }
};
