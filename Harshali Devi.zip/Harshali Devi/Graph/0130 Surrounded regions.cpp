//https://leetcode.com/problems/surrounded-regions/

//DFS

class Solution {
public:
    void dfs(int n, int m, int row, int col, vector<vector<char>>& board) {
        if (row < 0 || col < 0 || row >= n || col >= m || board[row][col] != 'O') return;

        board[row][col] = '*'; // Mark the cell as part of the boundary-connected region

        dfs(n,m,row+1,col,board);
        dfs(n,m,row-1,col,board);
        dfs(n,m,row,col-1,board);
        dfs(n,m,row,col+1,board);
    }

    void solve(vector<vector<char>>& board) {
        int n = board.size();
        if (n == 0) return;
        int m = board[0].size();

        // Run DFS from all boundary cells
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if ((i == 0 || j == 0 || i == n - 1 || j == m - 1) && board[i][j] == 'O') {
                    dfs(n, m, i, j, board);
                }
            }
        }

        // Convert cells
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (board[i][j] == 'O') {
                    board[i][j] = 'X'; // Flip surrounded 'O' to 'X'
                } else if (board[i][j] == '*') {
                    board[i][j] = 'O'; // Restore boundary-connected '*' back to 'O'
                }
            }
        }
    }
};
