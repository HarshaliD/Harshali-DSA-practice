//https://leetcode.com/problems/word-ladder/

class Solution {
public:
    int ladderLength(string beginWord, string endWord, vector<string>& wordList) {
        
        queue<pair<string,int>>q;      //{word,level}

        q.push({beginWord,1});

        unordered_set<string>sett(wordList.begin(),wordList.end());

        while(!q.empty()){
            string word = q.front().first;
            int level = q.front().second;

            q.pop();

            if(word==endWord) return level;

            for(int i=0;i<word.size();i++){
                char original = word[i];
                for(char j='a';j<='z';j++){
                    word[i]=j;
                    if(sett.find(word)!=sett.end()){
                        q.push({word,level+1});
                        sett.erase(word);
                    }
                }
                word[i]=original;
            }
        }


        return 0;


    }
};
