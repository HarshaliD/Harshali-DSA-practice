//https://leetcode.com/problems/find-center-of-star-graph/description/

//Approach 1 

class Solution {
public:
    int findCenter(vector<vector<int>>& edges) {
        
        int n = edges.size();
        vector<int>vis(n+2,0);

        for(int i=0;i<edges.size();i++){
            for(int j=0;j<2;j++){
                int num = edges[i][j];
                vis[num]++;
                if(vis[edges[i][j]]==n){
                    return num;
                }
            }
        }

        return -1;

    }
};

//Approach 2

class Solution {
public:
    int findCenter(vector<vector<int>>& edges) {
        // Extract nodes from the first two edges
        int u1 = edges[0][0], v1 = edges[0][1];
        int u2 = edges[1][0], v2 = edges[1][1];

        // Check which node is common in the two edges
        if (u1 == u2 || u1 == v2) return u1;
        return v1;
    }
};
