//https://leetcode.com/problems/minimum-number-of-vertices-to-reach-all-nodes/description/

class Solution {
public:
    vector<int> findSmallestSetOfVertices(int n, vector<vector<int>>& edges) {
        
        vector<int>inDegree(n,0);

        for(auto it : edges){
            int u = it[0];
            int v = it[1];
            inDegree[v]++;
        }

        vector<int>result;

        for(int i=0;i<n;i++){
            if(inDegree[i]==0){
                result.push_back(i);
            }
        }

        return result;
    }
};
