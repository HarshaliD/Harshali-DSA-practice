//https://leetcode.com/problems/01-matrix/description/

class Solution {
public:
    vector<vector<int>> updateMatrix(vector<vector<int>>& mat) {

        int n = mat.size();
        int m = mat[0].size();

        vector<vector<int>> visited(n, vector<int>(m, 0));  
        vector<vector<int>> distance(n, vector<int>(m, 0));

        queue<pair<pair<int, int>, int>> q;

        // Initialize BFS queue with all 0s and mark them visited
        for(int row = 0; row < n; row++) {
            for(int col = 0; col < m; col++) {
                if(mat[row][col] == 0) {
                    q.push({{row, col}, 0});
                    visited[row][col] = 1;               
                }
            }
        }

        // Directions for moving in 4 possible directions
        int drow[] = {0, 1, 0, -1};
        int dcol[] = {1, 0, -1, 0};

        while(!q.empty()) {
            int dist = q.front().second;
            int r = q.front().first.first;
            int c = q.front().first.second;
            q.pop();

            distance[r][c] = dist;

            for(int i = 0; i < 4; i++) {
                int nrow = r + drow[i];
                int ncol = c + dcol[i];

                if(nrow >= 0 && ncol >= 0 && nrow < n && ncol < m && mat[nrow][ncol]==1 && visited[nrow][ncol] == 0) {
                    visited[nrow][ncol] = 1;
                    q.push({{nrow, ncol}, dist + 1});
                }
            }
        }

        return distance;
    }
};
