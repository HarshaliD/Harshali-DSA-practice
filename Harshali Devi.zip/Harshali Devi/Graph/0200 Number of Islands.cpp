//https://leetcode.com/problems/number-of-islands/description/

class Solution {
public:
    void dfs(vector<vector<char>>& grid ,int row ,int col){

        //base condition
        if(col<0 || row<0 || row>=grid.size() || col>=grid[0].size() || grid[row][col]=='0'){
            return;
        }

        grid[row][col]='0';
        //left
        dfs(grid,row,col-1);
        //down
        dfs(grid,row+1,col);
        //right
        dfs(grid,row,col+1);
        //up
        dfs(grid,row-1,col);
        
    }
    int numIslands(vector<vector<char>>& grid) {
        int ans=0;

        for(int row=0;row<grid.size();row++){
            for(int col=0;col<grid[0].size();col++){
                if(grid[row][col]=='1'){
                    ans++;
                    dfs(grid,row,col);
                }
            }
        }
        return ans;
    }
};
