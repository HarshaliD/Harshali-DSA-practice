//https://leetcode.com/problems/number-of-provinces/description/

class Solution {
public:
    vector<int> bfsOfGraph(vector<int>&vis, int V, vector<vector<int>>& adj) {
        vis[V] = 1;
        vector<int> bfs;
        queue<int> q;
        q.push(V);

        while (!q.empty()) {
            int node = q.front();
            q.pop();
            bfs.push_back(node);

            for (auto v : adj[node]) {
                if (vis[v] != 1) {
                    vis[v] = 1;
                    q.push(v);
                }
            }
        }

        return bfs;
    }

    int findCircleNum(vector<vector<int>>& isConnected) {
        int V = isConnected.size();
        vector<vector<int>> adj(V);
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (isConnected[i][j] == 1 && i != j) {         //i!=j is to check for self loops
                    adj[i].push_back(j);
                    adj[j].push_back(i);
                }
            }
        }

        vector<int> vis(V, 0);
        int cnt = 0;
        for (int i = 0; i < V; i++) {
            if (!vis[i]) {
                cnt++;
                bfsOfGraph(vis, i, adj);
            }
        }

        return cnt;
    }
};
