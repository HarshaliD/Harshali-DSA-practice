//https://www.geeksforgeeks.org/problems/detect-cycle-in-an-undirected-graph/1

class Solution {
  public:
    // Function to detect cycle in an undirected graph.
    bool dfs(vector<int> adj[],int node,int parent,vector<int>&visited){
        
        visited[node]=1;
        
        for(auto point : adj[node]){
            if(!visited[point]){
                if(dfs(adj,point,node,visited)==true){
                    return true;
                }
            }
            else if(parent!=point)return true;
        }
        
        return false;
        
    }
    bool isCycle(int V, vector<int> adj[]) {
        
        vector<int>visited(V,0);
        
        for(int i=0;i<V;i++){
            if(!visited[i]){
                if(dfs(adj,i,-1,visited)==true)return true;
            }
        }
        
        return false;
    }
};
