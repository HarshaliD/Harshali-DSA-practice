//https://leetcode.com/problems/flood-fill/

class Solution {
public:
    void dfs(int n,int m,vector<vector<int>>& image,int row,int col,int color,int val){
        if(row>=n || col>=m || row<0 || col<0 || image[row][col]!=val){
            return;
        }
        
        image[row][col] = color;

        dfs(n,m,image,row+1,col,color,val);
        dfs(n,m,image,row-1,col,color,val);
        dfs(n,m,image,row,col+1,color,val);
        dfs(n,m,image,row,col-1,color,val);
        
    }
    vector<vector<int>> floodFill(vector<vector<int>>& image, int sr, int sc, int color) {
        
        int val = image[sr][sc];

        if (val == color) {  // Prevent infinite recursion
            return image;
        }

        int n=image.size();
        int m=image[0].size();

        dfs(n,m,image,sr,sc,color,val);

        return image;
    }
};
