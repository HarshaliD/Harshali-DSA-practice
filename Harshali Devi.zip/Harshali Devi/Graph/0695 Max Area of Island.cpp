//https://leetcode.com/problems/max-area-of-island/description/

class Solution {
public:
    int dfs(vector<vector<int>>& grid , int row , int col){
        //base condition
        if(col<0 || row<0 || col>=grid[0].size() || row>=grid.size() || grid[row][col]==0) return 0;

        int ans=1;
        grid[row][col]=0;

        ans+=dfs(grid,row+1,col);
        ans+=dfs(grid,row-1,col);
        ans+=dfs(grid,row,col+1);
        ans+=dfs(grid,row,col-1);

        return ans;
    }
    int maxAreaOfIsland(vector<vector<int>>& grid) {

        int maxArea = 0;

        for(int i=0;i<grid.size();i++){
            for(int j=0;j<grid[0].size();j++){
                if(grid[i][j]==1){
                    int area = dfs(grid,i,j);
                    maxArea = max(area,maxArea);
                }
            }
        }

        return maxArea;
    }
};

