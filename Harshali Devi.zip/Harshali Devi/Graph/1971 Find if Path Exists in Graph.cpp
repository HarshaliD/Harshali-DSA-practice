//https://leetcode.com/problems/find-if-path-exists-in-graph/description/

//dfs approach
class Solution {
public:
    void dfs(int node,vector<int>&visited,vector<vector<int>>&adjL){

        visited[node]=1;

        for(auto edge : adjL[node]){
            if(!visited[edge]){
                dfs(edge,visited,adjL);
            }
        }
        
    }
    bool validPath(int n, vector<vector<int>>& edges, int source, int destination) {
        vector<int> visited(n, 0);
        vector<vector<int>> adjL(n);

        for (int i = 0; i < edges.size(); i++) {
            adjL[edges[i][0]].push_back(edges[i][1]);
            adjL[edges[i][1]].push_back(edges[i][0]);
        }

        dfs(source,visited,adjL);

        return visited[destination] == 1;
    }
};

