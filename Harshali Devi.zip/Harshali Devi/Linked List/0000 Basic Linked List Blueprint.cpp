#include <iostream>
#include<vector>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int data1,Node* next1){
        data=data1;
        next=next1;
    }
    
    Node(int data1){
        data=data1;
        next=nullptr;
    }
};

Node* insertNodeAtLast(Node* head,int val){
    Node* newval = new Node(val);
    if(head==nullptr){
        return newval;
    }
    
    Node* temp = head;
    
    while(temp->next!=nullptr){
        temp=temp->next;
    }
    
    temp->next=newval;
    return head;
}

Node* insertAtStart(Node* head,int val){
    Node* newval = new Node(val);
    newval->next=head;
    head=newval;
    return head;
}

Node* insertInBetween(Node* head,int pos,int val){
    if(pos=0){
        return insertAtStart(head,val);
    }
    Node* newval = new Node(val);
    Node*temp = head;
    
    for(int i=0;i<=pos - 1 && temp != nullptr;i++){
        temp=temp->next;
    }
    
     if (temp == nullptr) {
        // If the position is beyond the end of the list, insert at the end
        return insertNodeAtLast(head, val);
    }
    
    newval->next = temp->next;
    temp->next = newval;
    return head;
    
}

void printList(Node* head){
    Node* temp = head;
    while(temp!=nullptr){
        cout<<temp->data<<"->";
        temp=temp->next;
    }
}



int main() {
    
    vector<int> arr={2,5,8,7};
    Node* head = new Node(arr[0]);
    
    for(int i=1;i<arr.size();i++){
        head=insertNodeAtLast(head,arr[i]);
    }
    
    head=insertAtStart(head,99);
    head=insertInBetween(head,2,1892);
    
    printList(head);
    return 0;
}
