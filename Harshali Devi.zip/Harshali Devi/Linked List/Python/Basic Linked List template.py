
class Node:
  def __init__(self, data):
    self.data = data
    self.next = None

class LinkedList: 
    def __init__(self, data):
        self.head = Node(data) 

    def insert(self, data):
        new_node = Node(data) 
        if self.head is None:
            self.head = new_node
        else:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = new_node   

    def print(self):
      temp = self.head
      while(temp):
        print(temp.data)
        temp = temp.next
      print("----------------")

    def delete(self, data):
      while self.head is not None and self.head.data == data:
          self.head = self.head.next

      temp = self.head

      while temp is not None and temp.next is not None:
          if temp.next.data == data:
              temp.next = temp.next.next  
          else:
              temp = temp.next 


llist = LinkedList(1)
llist.insert(2)
llist.insert(3)
llist.insert(4)
llist.insert(5)
llist.print()
llist.delete(3)
llist.print()
